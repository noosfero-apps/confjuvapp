var fillBackgroundWithColor = function(color) {
  document.body.style.background = document.getElementById('body').style.background = document.getElementById('proposals-container').style.background = color;
};
